/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/06 10:43:44 by norabino          #+#    #+#             */
/*   Updated: 2024/09/09 16:40:08 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

char	*ft_strcpy(char *dest, char *src)
{
	int	cpt;

	cpt = 0;
	while (src[cpt] != '\0')
	{
		dest[cpt] = src[cpt];
		cpt ++;
	}
	dest[cpt] = '\0';
	return (dest);
}
/*
int	main(void)
{
	char dest[3] = "";
	char *src = "Allo, ya dla merd dans le tuyau";
	ft_strcpy(dest, src);
	printf("%s", dest);
}
*/
