/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 14:14:37 by norabino          #+#    #+#             */
/*   Updated: 2024/09/16 09:14:45 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	longueur(char *str)
{
	int	cpt;

	cpt = 0;
	while (str[cpt])
		cpt++;
	return (cpt);
}

int	ft_str_is_alpha(char *str)
{
	int	i;
	int	c;

	if (longueur(str) == 0)
		return (1);
	i = 0;
	while (str[i] != '\0')
	{
		c = str[i];
		if (('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z'))
		{
			i ++;
		}
		else
			return (0);
	}
	return (1);
}
/*
int	main(void)
{
	char a[] = "Bonjour";
	printf("%d",ft_str_is_alpha(a));
}*/
