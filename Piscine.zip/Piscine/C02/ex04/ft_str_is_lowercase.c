/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 13:50:36 by norabino          #+#    #+#             */
/*   Updated: 2024/09/09 14:41:51 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_str_is_lowercase(char *str)
{
	int	cpt;

	cpt = 0;
	while (str[cpt] != '\0')
	{
		if (!(('a' <= str[cpt]) && (str[cpt] <= 'z')))
		{
			return (0);
		}
		cpt ++;
	}
	return (1);
}
/*
int	main(void)
{
	char a[] = "salut";
	printf("%d",ft_str_is_lowercase(a));
}
*/
