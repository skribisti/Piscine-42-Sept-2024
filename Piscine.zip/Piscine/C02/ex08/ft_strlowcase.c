/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 14:47:04 by norabino          #+#    #+#             */
/*   Updated: 2024/09/11 10:24:13 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

char	*ft_strlowcase(char *str)
{
	int	cpt;

	cpt = 0;
	while (str[cpt] != '\0')
	{
		if (('A' <= str[cpt]) && (str[cpt] <= 'Z'))
		{
			str[cpt] = str[cpt] + 32;
		}
		cpt ++;
	}
	return (str);
}
/*
int	main(void)
{
	char a[] = "SDHFDWFJOSDJOSFJ45sdsd";
	printf("%s",ft_strlowcase(a));
}
*/
