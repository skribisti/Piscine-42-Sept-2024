/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 13:47:25 by norabino          #+#    #+#             */
/*   Updated: 2024/09/09 14:41:10 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_str_is_numeric(char *str)
{
	int	cpt;

	cpt = 0;
	while (str[cpt] != '\0')
	{
		if (!(('0' <= str[cpt]) && (str[cpt] <= '9')))
		{
			return (0);
		}
		cpt ++;
	}
	return (1);
}
/*
int	main(void)
{
	char a[] = "123";
	printf("%d",ft_str_is_numeric(a));
}
*/
