/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 13:52:18 by norabino          #+#    #+#             */
/*   Updated: 2024/09/09 14:42:05 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_str_is_uppercase(char *str)
{
	int	cpt;

	cpt = 0;
	while (str[cpt] != '\0')
	{
		if (!(('A' <= str[cpt]) && (str[cpt] <= 'Z')))
		{
			return (0);
		}
		cpt ++;
	}
	return (1);
}
/*
int	main(void)
{
	char a[] = "SDSGSGSDF";
	printf("%d",ft_str_is_upppercase(a));
}
*/
