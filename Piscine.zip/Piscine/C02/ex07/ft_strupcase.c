/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 14:07:34 by norabino          #+#    #+#             */
/*   Updated: 2024/09/09 14:12:45 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

char	*ft_strupcase(char *str)
{
	int	cpt;

	cpt = 0;
	while (str[cpt] != '\0')
	{
		if (('a' <= str[cpt]) && (str[cpt] <= 'z'))
		{
			str[cpt] = str[cpt] - 32;
		}
		cpt ++;
	}
	return (str);
}
/*
int	main(void)
{
	char a[] = "shhfjakdHHJVH26dwdw";
	printf("%s",ft_strupcase(a));
}
*/
