/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 14:49:35 by norabino          #+#    #+#             */
/*   Updated: 2024/09/16 09:14:12 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	is_alphanum(char str)
{
	if ((str >= 'a' && str <= 'z')
		|| (str >= '0' && str <= '9')
		|| (str >= 'A' && str <= 'Z'))
		return (1);
	return (0);
}

int	ft_uppercase(char str)
{
	if (str >= 'A' && str <= 'Z')
		return (1);
	return (0);
}

int	ft_lowercase(char str)
{
	if (str >= 'a' && str <= 'z')
		return (1);
	return (0);
}

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (ft_lowercase(str[0]))
			str[0] = str[0] - 32;
		if (!is_alphanum(str[i - 1]) && ft_lowercase(str[i]))
			str[i] = str[i] - 32;
		if (is_alphanum(str[i - 1]) && ft_uppercase(str[i]))
			str[i] = str[i] + 32;
		i++;
	}
	return (str);
}
/*
int	main(void)
{
	char a[] = "saLut, coMMent tu vas ? 42mots quarante-deux; cinquante+et+un";
	printf("%s",ft_strcapitalize(a));
}*/
