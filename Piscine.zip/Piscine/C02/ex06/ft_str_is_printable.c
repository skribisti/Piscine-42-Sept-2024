/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 13:54:28 by norabino          #+#    #+#             */
/*   Updated: 2024/09/24 09:18:09 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_printable(char *str)
{
	int	cpt;

	cpt = 0;
	while (str[cpt] != '\0')
	{
		if (!((' ' <= str[cpt]) && (str[cpt] <= '~')))
		{
			return (0);
		}
		cpt ++;
	}
	return (1);
}
/*
int	main(void)
{
	char a[] = "Bon5df\0edeforFSA";
	printf("%d",ft_str_is_printable(a));
}*/
