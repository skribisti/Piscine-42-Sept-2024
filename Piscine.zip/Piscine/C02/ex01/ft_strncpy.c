/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 11:47:04 by norabino          #+#    #+#             */
/*   Updated: 2024/09/16 09:13:28 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	cpt;

	cpt = 0;
	while (src[cpt] != '\0' && (cpt < n))
	{
		dest[cpt] = src[cpt];
		cpt ++;
	}
	while (cpt < n)
	{
		dest[cpt] = '\0';
		cpt ++;
	}
	return (dest);
}
/*
int	main(void)
{
	char dest[50] = "";
	char *src = "Allo, ya dla merd dans le tuyau";
	ft_strncpy(dest, src, 3);
	printf("%s", dest);
}*/
