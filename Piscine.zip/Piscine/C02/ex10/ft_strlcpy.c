/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/23 10:10:35 by norabino          #+#    #+#             */
/*   Updated: 2024/09/23 10:29:58 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <bsd/string.h>

char	*ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	cpt;

	cpt = 0;
	while (src[cpt] != '\0' && (cpt < size - 1))
	{
		dest[cpt] = src[cpt];
		cpt ++;
	}
	dest[cpt] = '\0';
	return (dest);
}
/*
int	main(void)
{
	char dest1[50] = "";
	char dest2[50] = "";
	char *src = "Allo, ya dla merd dans le tuyau";
	ft_strlcpy(dest1, src, 5);
	strlcpy(dest2, src, 5); //compiler avec le flag -lbsd apres le nom
	printf("ma func : %s \n", dest1);
	printf("og func : %s \n", dest2);
}*/
