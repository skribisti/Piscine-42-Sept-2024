/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/12 09:39:14 by norabino          #+#    #+#             */
/*   Updated: 2024/09/12 10:04:42 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	i;
	int	n;

	i = (nb - 1);
	n = nb;
	if (nb < 0)
		return (0);
	if (nb == 0)
		return (1);
	while (i > 0)
	{
		n = n * i;
		i --;
	}
	return (n);
}
/*
#include <stdio.h>
int	main()
{
	printf("%d",ft_iterative_factorial(4));
	return 0;
}*/
