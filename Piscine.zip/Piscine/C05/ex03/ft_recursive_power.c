/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/12 10:39:20 by norabino          #+#    #+#             */
/*   Updated: 2024/09/12 11:16:52 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_recursive_power(int nb, int power)
{
	int	n;

	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	n = nb * ft_recursive_power(nb, power - 1);
	return (n);
}
/*
#include <stdio.h>
int	main()
{
	printf("%d", ft_recursive_power(2, 2));
}*/
