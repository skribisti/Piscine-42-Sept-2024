cd .. ; git check-ignore **/*
