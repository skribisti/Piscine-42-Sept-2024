/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/10 10:54:25 by norabino          #+#    #+#             */
/*   Updated: 2024/09/12 11:02:34 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	longueur(char	*str)
{
	int	i;

	i = 0;
	while (str[i] != '\0' )
	{
		i++;
	}
	return (i);
}

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	int				sized;
	unsigned int	cpt;

	sized = longueur(dest);
	cpt = 0;
	while ((src[cpt] != '\0') && (cpt < nb))
	{
		dest[cpt + sized] = src[cpt];
		cpt ++;
	}
	dest[cpt + sized] = '\0';
	return (dest);
}
/*
int	main(void)
{
	char dest[200] = "Allo";
	char src[] = "ya dla merd dans ltuyau";
	ft_strncat(dest, src, 5);
	printf("%s", dest);
}
*/
