/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/20 11:00:20 by norabino          #+#    #+#             */
/*   Updated: 2024/09/26 15:26:50 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

int    ft_strlen(char *c)
{
    int    i;

    i = 0;
    while (c[i] != '\0')
        i++;
    return (i);
}

char    *ft_strstr(char *str, char *to_find)
{
    int    i;
    int    j;

    i = 0;
    j = 0;
    if (to_find[0] == '\0')
    {
        if (str[i] == '\0')
            return ("");
        return (str);
    }
    while (str[i])
    {
        j = 0;
        while (str[i + j] == to_find[j])
        {
            j++;
            if (j == ft_strlen(to_find))
                return (&str[i - j] + ft_strlen(to_find));
        }
        i++;
    }
    return (0);
}

int main(int argc, char *argv[])
{
    char    *str = argv[1];
    char    *to_find = argv[2];
    
    (void)argc;
    printf("%s\n", str);
    printf("%s\n", strstr(str, to_find));
    printf("%s", ft_strstr(str, to_find));
    return (0);
}
