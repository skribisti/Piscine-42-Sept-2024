/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/26 15:31:18 by norabino          #+#    #+#             */
/*   Updated: 2024/09/26 15:57:44 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

unsigned int	strlen(char	*str)
{
	unsigned int	i;

	i = 0;
	while (str[i] != '\0' )
	{
		i++;
	}
	return (i);
}

char	*ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;

	i = 0;
	if (size > 0)
	{
		if (strlen(dest) >= size)
			return ()
		while ((src[i]) && strlen(dest) + i < size - 1)
		{
			dest[i + strlen(dest)] = src[i];
			i++;
		}
		dest[i + strlen(dest)] = '\0';
		return (strlen(dest), strlen(src));
	}
	return (strlen(src));
}
/*
int	main(void)
{
	char dest[200] = "Allo";
	char src[] = "ya dla merd dans ltuyau";
	ft_strlcat(dest, src, 5);
	printf("%s", dest);
}
*/
