/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/16 09:52:29 by norabino          #+#    #+#             */
/*   Updated: 2024/09/25 13:41:01 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	cpt;

	cpt = 0;
	while (str[cpt])
		cpt ++;
	return (cpt);
}

char	*ft_strcat(char *dest, char *src)
{
	int	sized;
	int	cpt;

	sized = ft_strlen(dest);
	cpt = 0;
	while (src[cpt] != '\0')
	{
		dest[cpt + sized] = src[cpt];
		cpt ++;
	}
	dest[cpt + sized] = '\0';
	return (dest);
}

int	total_length(int size, char **strs, char *sep)
{
	int	i;
	int	j;
	int	total;

	total = 0;
	i = 0;
	j = 0;
	while (strs[i])
	{
		while (strs[j])
		{
			j++;
		}
		total = total + j;
		i++;
	}
	total = total + (size - 1) * ft_strlen(sep);
	return (total);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*tab;
	int		i;

	if (size == 0)
	{
		tab = malloc(1 * sizeof(char));
		tab[0] = 0;
		return (tab);
	}
	tab = malloc(sizeof(char) * total_length(size, strs, sep) + 1);
	tab[0] = 0;
	i = 0;
	while (i < size)
	{
		tab = ft_strcat(tab, strs[i]);
		if (i != size - 1)
			tab = ft_strcat(tab, sep);
		i++;
	}
	return (tab);
}
/*
#include <stdio.h>

int	main(void)
{
	int		size;
	char	*strs[6];
	char	*sep;

	sep = " . ";
	size = 6;
	strs[0] = "Allo";
	strs[1] = "ya";
	strs[2] = "dla";
	strs[3] = "merd";
	strs[4] = "dans";
	strs[5] = "ltuyau";
    printf("%s", ft_strjoin(size, strs, sep));
    return (0);
}*/
