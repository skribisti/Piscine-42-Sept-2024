/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/26 11:37:30 by norabino          #+#    #+#             */
/*   Updated: 2024/09/26 16:20:53 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char	*str)
{
	int i = 0;
	while (str[i])
		i++;
	return i;
}

int	is_sep(char	c)
{
	if (c == ' ' || c == '\t' || c == '\n')
		return (1);
	return (0);
}

char	*ft_strndup(char	*str, int	n)
{
	char	*tab;
	int	i = 0;
	tab = (char *)malloc(ft_strlen(str + 1));
	while (str[i] && i < n)
	{
		tab[i] = str[i];
		i++;
	}
	tab[i] = 0;
	return (tab);
}

char	**ft_split(char	*str)
{
	char	**tab;
	int	i;
	int	f;	
	int	l;

	i = 0;
	l = 0;
	tab = (char **)malloc(sizeof(char *)* 999999);
	while (str[i])
	{
		while (str[i] && is_sep(str[i]))
			i++;
		f = i;
		while (str[f] && !is_sep(str[f]))
			f++;
		if (str[i])
			tab[l] = ft_strndup(str + i, f - i);
		i = f;
		l++;
	}
	tab[l] = 0;
	return (tab);
}

#include <stdio.h>

int		main()
{
 	char **arr;

 	char *phrase = "  allo  ya	dla		 merd	 dan		ltuyo";
 	arr = ft_split(phrase);
 	printf("%s\n", arr[0]);
 	printf("%s\n", arr[1]);
 	printf("%s\n", arr[2]);
	printf("%s\n", arr[3]);
	printf("%s\n", arr[4]);
	printf("%s\n", arr[5]);
}
