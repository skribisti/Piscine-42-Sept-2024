/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/13 10:24:43 by norabino          #+#    #+#             */
/*   Updated: 2024/09/25 13:36:12 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*tab;
	int	i;
	int	nb;
	int	size;

	size = max - min;
	i = 0;
	nb = min;
	if (size <= 0)
		return (0);
	tab = NULL;
	tab = (int *)malloc(sizeof(int) * size);
	if (!tab)
		return (NULL);
	while (i < size)
	{
		(tab)[i] = nb;
		i++;
		nb++;
	}
	return (tab);
}
/*
#include <stdio.h>
int	main()
{	int i;
	int	min = -10;
	int	max = 23;
	int *tablo;
	
	i = 0;
	tablo = ft_range(min, max);
	while (i < (max - min))
	{
		printf("%d\n", tablo[i]);
		i++;
	}
	free(tablo);
	return 0;
}*/
