/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/13 11:30:10 by norabino          #+#    #+#             */
/*   Updated: 2024/09/25 13:40:04 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	i;
	int	size;

	i = 0;
	size = (max - min);
	*range = malloc(sizeof(int) * size);
	if (size <= 0)
	{
		*range = NULL;
		return (0);
	}
	while (i < size)
	{
		(*range)[i] = min + i;
		i++;
	}
	return (size);
}
/*
#include <stdio.h>
int main(void)
{
    int *range;
    int i;
    int min;
    int max;
    int size;

    min = -10;
    max = 31;
    i = 0;

    // Appelle la fonction et récupère la taille du tableau
    size = ft_ultimate_range(&range, min, max);  // Passe l'adresse de range

    if (size == -1)
    {
        printf("Error: Memory allocation failed\n");
        return (1);
    }
	printf("size = %d\n", size);
    // Affiche les éléments du tableau
    while (i < size)
    {
        printf("%d\n", range[i]);
        i++;
    }

    // Libère la mémoire allouée
    free(range);
    
    return (0);
}*/
