/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/11 13:47:12 by norabino          #+#    #+#             */
/*   Updated: 2024/09/26 17:02:47 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *src)
{
	int	cpt;

	cpt = 0;
	while (src[cpt])
		cpt ++;
	return (cpt);
}

int	ft_check_base(char *base)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	if (ft_strlen(base) == 0 || ft_strlen(base) == 1)
		return (-1);
	while (base[i])
	{
		if ((!(base[i] > ' ' && base[i] <= '~'))
			|| (base[i] >= 9 && base[i] <= 13))
			return (-1);
		if (base[i] == '+' || base[i] == '-')
			return (-1);
		while (base[j])
		{
			if (base[i] == base[j] && i != j)
				return (-1);
			j++;
		}
		i++;
		j = 0;
	}
	return (1);
}

void	ft_putnbr_base(int nbr, char *base)
{
	long	nb;
	
	if (ft_check_base(base) == -1)
		return ;
	if (nbr == -2147483648)
	{
		write(1, "-2147483648", 11);
		return ;
	}
	if (nbr < 0)
	{
		nbr = -nbr;
		write(1, "-", 1);
	}
	if (nbr > ft_strlen(base) - 1)
		ft_putnbr_base(nbr / ft_strlen(base), base);
	write(1, &base[nbr % ft_strlen(base)], 1);
}
/*
int main()
{
	ft_putnbr_base(63, "pon\neyvif");
}*/
