/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/11 14:30:26 by norabino          #+#    #+#             */
/*   Updated: 2024/09/17 12:05:51 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_numeric(char str)
{
	if (!((str >= '0') && (str <= '9')))
	{
		return (0);
	}
	return (1);
}

int	ft_atoi(char	*str)
{
	int	res;
	int	signe;
	int	i;

	i = 0;
	signe = 1;
	res = 0;
	while ((str[i] == 32) || (str[i] >= 9 && str[i] <= 13))
	{
		i++;
	}
	while ((str[i] == '-') || (str[i] == '+'))
	{
		if (str[i] == '-')
			signe = -signe;
		i++;
	}
	while (ft_str_is_numeric(str[i]))
	{
		res = res * 10 + str[i] - 48;
		i++;
	}
	return (res * signe);
}
/*
int	main(void)
{
	printf("%d", ft_atoi("+--+-50fd-1"));
	return (0);
}*/
