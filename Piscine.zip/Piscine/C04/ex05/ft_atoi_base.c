/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/17 11:05:36 by norabino          #+#    #+#             */
/*   Updated: 2024/09/19 10:55:43 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	ft_in_base(char el, char *base)
{
	int	i;

	i = 0;
	while (i < ft_strlen(base))
	{
		if (base[i] == el)
			return (i);
		i++;
	}
	return (-1);
}

int	ft_check_base(char *base)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	if (ft_strlen(base) == 0 || ft_strlen(base) == 1)
		return (-1);
	while (base[i])
	{
		if ((!(base[i] > ' ' && base[i] <= '~'))
			|| (base[i] >= 9 && base[i] <= 13))
			return (-1);
		if (base[i] == '+' || base[i] == '-')
			return (-1);
		while (base[j])
		{
			if (base[i] == base[j] && i != j)
				return (-1);
			j++;
		}
		i++;
		j = 0;
	}
	return (1);
}

int	ft_atoi_base(char *str, char *base)
{
	int	res;
	int	signe;
	int	i;

	if (ft_check_base(base) == -1)
		return (0);
	i = 0;
	signe = 1;
	res = 0;
	while ((str[i] == 32) || (str[i] >= 9 && str[i] <= 13))
		i++;
	while ((str[i] == '-') || (str[i] == '+'))
	{
		if (str[i] == '-')
			signe = -signe;
		i++;
	}
	while (ft_in_base(str[i], base) != -1)
	{
		res = res * ft_strlen(base) + ft_in_base(str[i], base);
		i++;
	}
	return (res * signe);
}
/*
int	main()
{
	printf("%d", ft_atoi_base("-21", "01123456789"));
}*/
