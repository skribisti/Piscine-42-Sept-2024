/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/04 16:42:51 by norabino          #+#    #+#             */
/*   Updated: 2024/09/05 10:51:00 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_is_negative(int n)
{
	char	pos;
	char	neg;
	int		zero;

	zero = 0;
	pos = 'P';
	neg = 'N';
	if (n < zero)
	{
		write(1, &neg, 1);
	}
	else
	{
		write(1, &pos, 1);
	}
}
/*
int	main(void)
{
	int	nb;

	nb = -15;
	ft_is_negative(nb);
}
*/
