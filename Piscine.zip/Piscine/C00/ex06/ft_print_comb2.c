/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/19 12:01:50 by norabino          #+#    #+#             */
/*   Updated: 2024/09/23 09:27:36 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char z)
{
	write(1, &z, 1);
}

void	ft_print(int c1, int c2)
{
	ft_putchar(c1 / 10 + '0');
	ft_putchar(c1 % 10 + '0');
	write(1, " ", 1);
	ft_putchar(c2 / 10 + '0');
	ft_putchar(c2 % 10 + '0');
	if (!(c1 == 98 && c2 == 99))
		write(1, ",  ", 2);
}

void	ft_print_comb2(void)
{
	int	a;
	int	b;

	a = 0;
	b = 0;
	while (a <= 98)
	{
		b = a + 1;
		while (b <= 99)
		{
			ft_print(a, b);
			b ++;
		}
		a ++;
	}
}
/*
int	main()
{
	ft_print_comb2();
	return 0;
}*/
