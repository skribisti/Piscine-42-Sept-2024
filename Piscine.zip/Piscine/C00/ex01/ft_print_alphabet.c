/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/04 14:47:37 by norabino          #+#    #+#             */
/*   Updated: 2024/09/05 10:45:49 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_alphabet(void)
{
	char	lettre;

	lettre = 'a';
	while ((lettre) != ('z' + 1))
	{
		write(1, &lettre, 1);
		lettre++;
	}
}
/*
int	main(void)
{
	ft_print_alphabet();
	return (0);
}
*/
