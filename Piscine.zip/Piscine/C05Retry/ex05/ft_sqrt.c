/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/12 11:32:41 by norabino          #+#    #+#             */
/*   Updated: 2024/09/18 17:20:07 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_sqrt(int nb)
{
	int	n;

	n = 0;
	while ((n * n) < nb && n <= 36341)
	{
		n ++;
	}
	if ((n * n) == nb)
		return (n);
	else
		return (0);
}
/*
#include <stdio.h>
int	main()
{
	printf("%d", ft_sqrt(25));
	return (1);
}*/
