/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/18 15:59:15 by norabino          #+#    #+#             */
/*   Updated: 2024/09/18 17:27:47 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_prime(int nb)
{
	int	i;
	if (nb < 0)
		return (0);
	if (nb == 0 || nb == 1)
		return (0);
	i = nb - 1;
	while (i > 1)
	{
		if (nb % i == 0)
			return (0);
		i--;
	}
	return (1);
}

int	ft_find_next_prime(int nb)
{
	int	n;

	n = nb;
	while (!ft_is_prime(n))
		n++;
	return (n);
}
/*
#include <stdio.h>
int	main()
{
	printf("%d", ft_find_next_prime(14));
}*/
