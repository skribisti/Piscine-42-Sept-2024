/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 11:16:41 by norabino          #+#    #+#             */
/*   Updated: 2024/09/09 11:16:46 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <unistd.h>
//#include <stdio.h>

void	ft_div_mod(int a, int b, int	*div, int	*mod)
{
	*mod = a % b;
	*div = a / b;
}
/*
int	main(void)
{
	int	a = 15;
	int	b = 10;
	int	c = 0;
	int	d = 0;

	ft_div_mod(a, b, &c, &d );:Wq


	write(1, &a, 1);
	write(1, &b, 1);
	write(1, &c, 1);
	write(1, &d, 1);
	printf("div :%d",c);
	printf("mod :%d",d);

	return (0);
}
*/
