/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/19 17:39:12 by norabino          #+#    #+#             */
/*   Updated: 2024/09/23 10:00:51 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

void	ft_swap(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

void	ft_rev_int_tab(int *tab, int size)
{
	int	i;
	int	j;

	i = 0;
	while (i * 2 < size)
	{
		j = (size - 1) - i;
		ft_swap(&tab[i], &tab[j]);
		i++;
	}
}
/*
int	main()
{
	int	tab[3000];
	tab[0] = 1;
	tab[1] = 2;
	tab[2] = 0;
	tab[3] = 4;
	tab[4] = 5;
	tab[5] = -1;
	tab[6] = -2;
	ft_rev_int_tab(tab, 7);
	
	int	i = 0;
	while (i < 7)
	{
		printf("%d", tab[i]);
		i++;
	}
}*/
