/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: norabino <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 11:14:19 by norabino          #+#    #+#             */
/*   Updated: 2024/09/09 11:14:27 by norabino         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}
/*
int	main(void)
{
	int	*********ptr9;
	int ********ptr8;
	int *******ptr7;
	int	******ptr6;
	int	*****ptr5;
	int	****ptr4;
	int	***ptr3;
	int	**ptr2;
	int	*ptr1;
	int a;

	ptr9 = &ptr8;
	ptr8 = &ptr7;
	ptr7 = &ptr6;
	ptr6 = &ptr5;
	ptr5 = &ptr4;
	ptr4 = &ptr3;
	ptr3 = &ptr2;
	ptr2 = &ptr1;
	ptr1 = &a;
	a = 0;
	ft_ultimate_ft(ptr9);
	printf("%d", a);
	return 0;
}
*/
